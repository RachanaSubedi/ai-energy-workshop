"""
train_rl_frequency_agent.py

Training script for the RL fast frequency response example.

This script:
    1. Creates the frequency-response environment
    2. Trains a DDPG agent
    3. Saves a partially trained model for workshop fine-tuning
    4. Saves a better pretrained model for instructor demonstration
"""

import os
import random
import numpy as np
import torch
import matplotlib.pyplot as plt

from src.frequency_env import FrequencyResponseEnv
from src.ddpg_agent import DDPGAgent, DDPGConfig


# -----------------------------
# Reproducibility
# -----------------------------
SEED = 469

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# -----------------------------
# Paths
# -----------------------------
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)

STARTING_ACTOR_PATH = os.path.join(MODEL_DIR, "rl_actor_starting_point.pt")
STARTING_CRITIC_PATH = os.path.join(MODEL_DIR, "rl_critic_starting_point.pt")

PRETRAINED_ACTOR_PATH = os.path.join(MODEL_DIR, "rl_actor_pretrained.pt")
PRETRAINED_CRITIC_PATH = os.path.join(MODEL_DIR, "rl_critic_pretrained.pt")


# -----------------------------
# Device
# -----------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)


# -----------------------------
# Environment
# -----------------------------
env = FrequencyResponseEnv(
    dt=0.05,
    episode_time=7.50,
    H=5.0,
    D=1.0,
    p_ctrl_max=0.3,
    disturbance_range=(0.05, 0.25),
    disturbance_time_range=(0.5, 1.5),
    seed=SEED,
)

state_dim = env.observation_space.shape[0]
action_dim = env.action_space.shape[0]
action_limit = float(env.action_space.high[0])


# -----------------------------
# Agent
# -----------------------------
config = DDPGConfig(
    gamma=0.99,
    tau=0.005,
    actor_lr=1e-4,
    critic_lr=1e-3,
    batch_size=128,
    replay_capacity=100_000,
    exploration_noise=0.08,
)

agent = DDPGAgent(
    state_dim=state_dim,
    action_dim=action_dim,
    action_limit=action_limit,
    device=device,
    config=config,
)


# -----------------------------
# Training settings
# -----------------------------
N_EPISODES = 500
STARTING_POINT_EPISODE = 100
UPDATES_PER_STEP = 1

episode_rewards = []


# -----------------------------
# Training loop
# -----------------------------
for episode in range(1, N_EPISODES + 1):
    state, info = env.reset(seed=SEED + episode)

    total_reward = 0.0
    actor_losses = []
    critic_losses = []

    for step in range(env.max_steps):
        action = agent.select_action(state, add_noise=True)

        next_state, reward, terminated, truncated, info = env.step(action)
        done = terminated or truncated

        agent.replay_buffer.push(
            state,
            action,
            reward,
            next_state,
            float(done),
        )

        for _ in range(UPDATES_PER_STEP):
            losses = agent.update()
            if losses is not None:
                actor_losses.append(losses["actor_loss"])
                critic_losses.append(losses["critic_loss"])

        state = next_state
        total_reward += reward

        if done:
            break

    episode_rewards.append(total_reward)

    if episode == STARTING_POINT_EPISODE:
        agent.save(STARTING_ACTOR_PATH, STARTING_CRITIC_PATH)
        print(f"Saved starting-point model at episode {episode}")

    if episode % 25 == 0:
        avg_reward = np.mean(episode_rewards[-25:])
        print(
            f"Episode {episode:4d} | "
            f"Avg reward (last 25): {avg_reward:9.3f} | "
            f"Replay size: {len(agent.replay_buffer)}"
        )


# -----------------------------
# Save final pretrained model
# -----------------------------
agent.save(PRETRAINED_ACTOR_PATH, PRETRAINED_CRITIC_PATH)

print("Training complete.")
print("Saved:")
print(" ", STARTING_ACTOR_PATH)
print(" ", STARTING_CRITIC_PATH)
print(" ", PRETRAINED_ACTOR_PATH)
print(" ", PRETRAINED_CRITIC_PATH)


# -----------------------------
# Plot training curve
# -----------------------------
plt.figure()
plt.plot(episode_rewards)
plt.xlabel("Episode")
plt.ylabel("Total reward")
plt.title("DDPG Training Curve")
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(MODEL_DIR, "rl_training_curve.png"), dpi=200)
plt.show()
