"""
frequency_env.py

Gymnasium environment for fast frequency response using a simplified
single-area swing-equation frequency model.

State:
    [frequency_deviation_hz, rocof_hz_per_s, energy_pu]

Action:
    battery/inverter power injection in pu, continuous in [-p_ctrl_max, p_ctrl_max]
"""

from __future__ import annotations

import numpy as np
import gymnasium as gym
from gymnasium import spaces


class FrequencyResponseEnv(gym.Env):
    metadata = {"render_modes": []}

    def __init__(
        self,
        dt: float = 0.05,
        episode_time: float = 7.50,
        H: float = 5.0,
        D: float = 1.0,
        p_ctrl_max: float = 0.3,
        energy_init: float = 1.0,
        energy_min: float = 0.0,
        energy_max: float = 1.0,
        disturbance_range: tuple[float, float] = (0.05, 0.25),
        disturbance_time_range: tuple[float, float] = (0.5, 1.5),
        freq_limit: float = 0.5,
        seed: int | None = None,
    ):
        super().__init__()

        self.dt = dt
        self.episode_time = episode_time
        self.max_steps = int(episode_time / dt)

        self.H = H
        self.D = D
        self.p_ctrl_max = p_ctrl_max

        self.energy_init = energy_init
        self.energy_min = energy_min
        self.energy_max = energy_max

        self.disturbance_range = disturbance_range
        self.disturbance_time_range = disturbance_time_range
        self.freq_limit = freq_limit

        self.observation_space = spaces.Box(
            low=np.array([-5.0, -10.0, self.energy_min], dtype=np.float32),
            high=np.array([5.0, 10.0, self.energy_max], dtype=np.float32),
            dtype=np.float32,
        )

        self.action_space = spaces.Box(
            low=np.array([-self.p_ctrl_max], dtype=np.float32),
            high=np.array([self.p_ctrl_max], dtype=np.float32),
            dtype=np.float32,
        )

        self.np_random = np.random.default_rng(seed)

        self.step_count = 0
        self.t = 0.0
        self.freq_dev = 0.0
        self.rocof = 0.0
        self.energy = self.energy_init
        self.disturbance = 0.0
        self.disturbance_time = 1.0

    def reset(self, seed: int | None = None, options: dict | None = None):
        super().reset(seed=seed)

        if seed is not None:
            self.np_random = np.random.default_rng(seed)

        self.step_count = 0
        self.t = 0.0

        self.freq_dev = 0.0
        self.rocof = 0.0
        self.energy = self.energy_init

        self.disturbance = self.np_random.uniform(*self.disturbance_range)
        self.disturbance_time = self.np_random.uniform(*self.disturbance_time_range)

        obs = self._get_obs()
        info = {
            "disturbance": self.disturbance,
            "disturbance_time": self.disturbance_time,
        }

        return obs, info

    def step(self, action):
        action = np.asarray(action, dtype=np.float32)
        p_ctrl = float(np.clip(action[0], -self.p_ctrl_max, self.p_ctrl_max))

        # No disturbance before disturbance_time.
        p_dist = self.disturbance if self.t >= self.disturbance_time else 0.0

        # Prevent discharging when energy is depleted.
        if self.energy <= self.energy_min and p_ctrl > 0:
            p_ctrl = 0.0

        # Simplified swing equation:
        # d(df)/dt = (P_ctrl - P_dist - D*df) / (2H)
        self.rocof = (p_ctrl - p_dist - self.D * self.freq_dev) / (2.0 * self.H)

        self.freq_dev += self.dt * self.rocof

        # Simple energy update. Positive p_ctrl means discharge/injection.
        self.energy -= self.dt * max(p_ctrl, 0.0)
        self.energy = float(np.clip(self.energy, self.energy_min, self.energy_max))

        self.t += self.dt
        self.step_count += 1

        reward = self._reward(p_ctrl)

        terminated = abs(self.freq_dev) > 2.0
        truncated = self.step_count >= self.max_steps

        obs = self._get_obs()

        info = {
            "time": self.t,
            "p_ctrl": p_ctrl,
            "p_dist": p_dist,
            "freq_dev": self.freq_dev,
            "rocof": self.rocof,
            "energy": self.energy,
        }

        return obs, reward, terminated, truncated, info

    def _get_obs(self):
        return np.array(
            [self.freq_dev, self.rocof, self.energy],
            dtype=np.float32,
        )

    def _reward(self, p_ctrl: float):
        freq_penalty = 20.0 * self.freq_dev**2
        rocof_penalty = 2.0 * self.rocof**2
        control_penalty = 0.1 * p_ctrl**2
        limit_penalty = 50.0 * max(0.0, abs(self.freq_dev) - self.freq_limit) ** 2

        return -(freq_penalty + rocof_penalty + control_penalty + limit_penalty)


def droop_controller(obs, k_droop: float = 8.0, p_ctrl_max: float = 0.3):
    freq_dev, _, energy = obs

    # If frequency is below nominal, freq_dev is negative, so inject positive power.
    p_ctrl = -k_droop * freq_dev

    if energy <= 0.0 and p_ctrl > 0:
        p_ctrl = 0.0

    return np.array([np.clip(p_ctrl, -p_ctrl_max, p_ctrl_max)], dtype=np.float32)


if __name__ == "__main__":
    env = FrequencyResponseEnv(seed=469)

    obs, info = env.reset()
    print("Initial observation:", obs)
    print("Disturbance info:", info)

    total_reward = 0.0

    for _ in range(env.max_steps):
        action = droop_controller(obs, p_ctrl_max=env.p_ctrl_max)
        obs, reward, terminated, truncated, info = env.step(action)
        total_reward += reward

        if terminated or truncated:
            break

    print("Final observation:", obs)
    print("Total reward:", total_reward)
    print("Final info:", info)
