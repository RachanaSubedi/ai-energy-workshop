"""
ddpg_agent.py

Basic DDPG components for continuous-control reinforcement learning.

DDPG = Deep Deterministic Policy Gradient.

It is useful here because:
    - the state is continuous: [frequency deviation, RoCoF, energy]
    - the action is continuous: inverter/battery power injection
"""

from __future__ import annotations

from dataclasses import dataclass
import random
from collections import deque

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


class Actor(nn.Module):
    """
    Actor network.

    Input:
        state vector

    Output:
        continuous action in [-action_limit, action_limit]
    """

    def __init__(self, state_dim: int, action_dim: int, action_limit: float):
        super().__init__()

        self.action_limit = action_limit

        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim),
            nn.Tanh(),
        )

    def forward(self, state):
        return self.action_limit * self.net(state)


class Critic(nn.Module):
    """
    Critic network.

    Input:
        state and action

    Output:
        Q-value, which estimates how good that action is in that state
    """

    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)


class ReplayBuffer:
    """
    Stores past experience tuples:

        (state, action, reward, next_state, done)

    DDPG samples random batches from this buffer for training.
    """

    def __init__(self, capacity: int = 100_000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)

        states, actions, rewards, next_states, dones = zip(*batch)

        return (
            np.array(states, dtype=np.float32),
            np.array(actions, dtype=np.float32),
            np.array(rewards, dtype=np.float32).reshape(-1, 1),
            np.array(next_states, dtype=np.float32),
            np.array(dones, dtype=np.float32).reshape(-1, 1),
        )

    def __len__(self):
        return len(self.buffer)


@dataclass
class DDPGConfig:
    gamma: float = 0.99
    tau: float = 0.005
    actor_lr: float = 1e-4
    critic_lr: float = 1e-3
    batch_size: int = 128
    replay_capacity: int = 100_000
    exploration_noise: float = 0.05


class DDPGAgent:
    """
    DDPG agent.

    The actor chooses actions.
    The critic evaluates actions.
    Target networks stabilize learning.
    """

    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        action_limit: float,
        device: torch.device | str = "cpu",
        config: DDPGConfig | None = None,
    ):
        self.device = torch.device(device)
        self.config = config or DDPGConfig()

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_limit = action_limit

        self.actor = Actor(state_dim, action_dim, action_limit).to(self.device)
        self.actor_target = Actor(state_dim, action_dim, action_limit).to(self.device)

        self.critic = Critic(state_dim, action_dim).to(self.device)
        self.critic_target = Critic(state_dim, action_dim).to(self.device)

        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=self.config.actor_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=self.config.critic_lr)

        self.replay_buffer = ReplayBuffer(capacity=self.config.replay_capacity)

    def select_action(self, state, add_noise: bool = True):
        """
        Select action from the actor network.

        During training, we add noise so the agent explores.
        During evaluation, we do not add noise.
        """
        state_tensor = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)

        self.actor.eval()
        with torch.no_grad():
            action = self.actor(state_tensor).cpu().numpy()[0]
        self.actor.train()

        if add_noise:
            noise = np.random.normal(
                loc=0.0,
                scale=self.config.exploration_noise,
                size=self.action_dim,
            )
            action = action + noise

        action = np.clip(action, -self.action_limit, self.action_limit)
        return action.astype(np.float32)

    def update(self):
        """
        Perform one DDPG update step.

        Returns:
            dictionary with actor and critic losses,
            or None if the replay buffer is not ready.
        """
        if len(self.replay_buffer) < self.config.batch_size:
            return None

        states, actions, rewards, next_states, dones = self.replay_buffer.sample(
            self.config.batch_size
        )

        states = torch.as_tensor(states, dtype=torch.float32, device=self.device)
        actions = torch.as_tensor(actions, dtype=torch.float32, device=self.device)
        rewards = torch.as_tensor(rewards, dtype=torch.float32, device=self.device)
        next_states = torch.as_tensor(next_states, dtype=torch.float32, device=self.device)
        dones = torch.as_tensor(dones, dtype=torch.float32, device=self.device)

        # -------------------------
        # Critic update
        # -------------------------
        with torch.no_grad():
            next_actions = self.actor_target(next_states)
            target_q = self.critic_target(next_states, next_actions)
            y = rewards + self.config.gamma * (1.0 - dones) * target_q

        current_q = self.critic(states, actions)
        critic_loss = nn.functional.mse_loss(current_q, y)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # -------------------------
        # Actor update
        # -------------------------
        predicted_actions = self.actor(states)
        actor_loss = -self.critic(states, predicted_actions).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # -------------------------
        # Target network soft update
        # -------------------------
        self._soft_update(self.actor_target, self.actor)
        self._soft_update(self.critic_target, self.critic)

        return {
            "actor_loss": float(actor_loss.item()),
            "critic_loss": float(critic_loss.item()),
        }

    def _soft_update(self, target_net, source_net):
        tau = self.config.tau

        for target_param, source_param in zip(target_net.parameters(), source_net.parameters()):
            target_param.data.copy_(
                tau * source_param.data + (1.0 - tau) * target_param.data
            )

    def save(self, actor_path: str, critic_path: str):
        torch.save(self.actor.state_dict(), actor_path)
        torch.save(self.critic.state_dict(), critic_path)

    def load(self, actor_path: str, critic_path: str | None = None):
        self.actor.load_state_dict(torch.load(actor_path, map_location=self.device))
        self.actor_target.load_state_dict(self.actor.state_dict())

        if critic_path is not None:
            self.critic.load_state_dict(torch.load(critic_path, map_location=self.device))
            self.critic_target.load_state_dict(self.critic.state_dict())
